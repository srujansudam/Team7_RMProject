package com.cg.ibs.rm.ui;

public enum TransactionMode {
	ONLINE,CASH
}
